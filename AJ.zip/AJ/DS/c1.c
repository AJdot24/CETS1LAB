#include<stdio.h>
int main()
{ 
float n,a[100],sum=0;

printf("Enter size of array");
scanf("%f",&n);
printf("Enter the values to be added:");
for(int i=0;i<n;i++)
{
scanf("%f",&a[i]);
sum=sum+a[i];
}
printf("%f",sum);
return 0;
}

