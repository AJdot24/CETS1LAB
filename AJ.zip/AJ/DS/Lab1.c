#include<stdio.h>
int update(int newval,int loc,int n,int a[100]);
int delete(int val,int loc,int n,int a[100]);
int main()
{
int a[100],n;
int newval,loc,val;
printf("Enter size of arary :");
scanf("%d",&n);
for(int i=0;i<n;i++) //insertion
{
scanf("%d",&a[i]);
}
for(int i=0;i<n;i++) //traverse
{
printf("%d",a[i]);
}
printf("Value to be deleted :");
scanf("%d",&newval);
printf("location to be deleted :");
scanf("%d",&loc);
delete(newval,loc,n,a);
}
int update(int newval,int loc,int n,int a[100])
{
if(loc>n)
{ printf("Location is invalid:");
}
else{
a[loc]=newval;
}
for(int i=0;i<n;i++) //traverse
{
printf("%d",a[i]);
}
}
int delete(int val,int loc,int n,int a[100])
{
for(int i=0;i<n;i++) 
{
if(a[i]==val)
{
int temp=i;
for(int i=temp;i<n;i++)
{
a[i]=a[i+1];
}
n=n-1;
}
}
for(int i=0;i<n;i++) //traverse
{
printf("%d",a[i]);
}
}
