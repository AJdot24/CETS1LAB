a=int(input("Enter first Number: "))
b=int(input("Second number: "))
c=int(input("Third number: "))
if((a>b)and(a>c)):
    print(a," is greatest")
elif((b>a) and (b>c)):
    print(b,"is greatest")
else:
    print(c,"is greatest")
