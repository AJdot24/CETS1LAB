a=float(input("Enter temperature in Celsius : "))
F=(a*1.8)+32
K=a+273.15
print("Fahrenheit = ",F)
print("Kelvin = ",K)
