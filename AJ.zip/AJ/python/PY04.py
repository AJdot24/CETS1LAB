a=int(input("Enter Value of a :"))
b=int(input("Enter Value of b :"))
print("a = ",a)
print("b = " ,b)
a,b=b,a
print("a = ",a)
print("b = " ,b)
