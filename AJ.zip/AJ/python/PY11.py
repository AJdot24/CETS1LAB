a=input("Enter file name with extension: ")
a=a.split('.')
print(a[1])
