a=input("Enter values seperated by comma ',' :")
a=a.split(',')
print(a)
