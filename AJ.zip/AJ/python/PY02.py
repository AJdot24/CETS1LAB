import math
a=float(input("enter radius of circle : "))
p=math.pi
Area=p*a*a
Circum=2*p*a
print("Aera = ",Area)
print("Circumfarance = ",Circum)
