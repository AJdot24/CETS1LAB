a=int(input("Enter first Number "))
if(a%2==0):
    print("Even number")
else:
    print("Odd number")
