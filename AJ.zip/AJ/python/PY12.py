a=input("Enter colours names seperated by ',' :")
a=a.split(',')
print(a[0],a[-1])
