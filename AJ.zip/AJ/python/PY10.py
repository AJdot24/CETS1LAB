a=input("Enter the string: ")
b=a[::-1]
if(a==b):
    print("palindrome")
else:
    print("NOT PALINDROME")
